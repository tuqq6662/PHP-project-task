<?php
session_start();

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class Database {
    private $conn;
    private $host = 'localhost';
    private $dbname = 'password_manager';
    private $user = 'root';
    private $password = '';

    // Connect to the database
    public function connect() {
        try {
            $this->conn = new PDO("mysql:host=$this->host;dbname=$this->dbname", $this->user, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $this->conn;
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            die("Connection failed: " . $e->getMessage());
        }
    }
}

class User {
    private $db;

    // Constructor with dependency injection
    public function __construct(Database $db) {
        $this->db = $db->connect();
    }

    // Register a new user
    public function register($username, $password) {
        try {
            // Check if username already exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetchColumn() > 0) {
                return "Username already exists";
            }

            $passwordHash = password_hash($password, PASSWORD_BCRYPT);
            $encryptionKey = openssl_encrypt($password, 'AES-256-CBC', $password, 0, '1234567890123456');
            
            if ($encryptionKey === false) {
                error_log("Encryption failed for username: $username");
                return "Encryption failed";
            }

            $stmt = $this->db->prepare("INSERT INTO users (username, password_hash, encryption_key) VALUES (?, ?, ?)");
            $result = $stmt->execute([$username, $passwordHash, $encryptionKey]);
            if ($result) {
                error_log("User registered successfully: $username");
                return true;
            } else {
                error_log("Failed to register user: $username");
                return "Registration failed";
            }
        } catch (PDOException $e) {
            error_log("Registration error: " . $e->getMessage());
            return "Database error: " . $e->getMessage();
        }
    }

    // Authenticate user login
    public function login($username, $password) {
        $stmt = $this->db->prepare("SELECT user_id, password_hash FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['user_id'];
            error_log("User logged in: $username");
            return true;
        }
        error_log("Login failed for username: $username");
        return false;
    }

    // Update user password and encryption key
    public function updatePassword($userId, $newPassword) {
        $passwordHash = password_hash($newPassword, PASSWORD_BCRYPT);
        $encryptionKey = openssl_encrypt($newPassword, 'AES-256-CBC', $newPassword, 0, '1234567890123456');
        
        $stmt = $this->db->prepare("UPDATE users SET password_hash = ?, encryption_key = ? WHERE user_id = ?");
        return $stmt->execute([$passwordHash, $encryptionKey, $userId]);
    }
}

class PasswordGenerator {
    private $length;
    private $lowercaseCount;
    private $uppercaseCount;
    private $numberCount;
    private $specialCharCount;

    // Set password generation parameters
    public function setParameters($length, $lowercaseCount, $uppercaseCount, $numberCount, $specialCharCount) {
        $this->length = $length;
        $this->lowercaseCount = $lowercaseCount;
        $this->uppercaseCount = $uppercaseCount;
        $this->numberCount = $numberCount;
        $this->specialCharCount = $specialCharCount;
    }

    // Generate a random password based on parameters
    public function generatePassword() {
        $lowercase = 'abcdefghijklmnopqrstuvwxyz';
        $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $numbers = '0123456789';
        $special = '!@#$%^&*().';
        $password = '';

        for ($i = 0; $i < $this->lowercaseCount; $i++) {
            $password .= $lowercase[rand(0, strlen($lowercase) - 1)];
        }
        for ($i = 0; $i < $this->uppercaseCount; $i++) {
            $password .= $uppercase[rand(0, strlen($uppercase) - 1)];
        }
        for ($i = 0; $i < $this->numberCount; $i++) {
            $password .= $numbers[rand(0, strlen($numbers) - 1)];
        }
        for ($i = 0; $i < $this->specialCharCount; $i++) {
            $password .= $special[rand(0, strlen($special) - 1)];
        }

        $password = str_shuffle($password);
        return substr($password, 0, $this->length);
    }
}

class PasswordManager {
    private $db;
    private $userId;

    // Constructor with dependency injection
    public function __construct(Database $db, $userId) {
        $this->db = $db->connect();
        $this->userId = $userId;
    }

    // Save a password for a website
    public function savePassword($website, $password) {
        $stmt = $this->db->prepare("INSERT INTO passwords (user_id, website, password) VALUES (?, ?, ?)");
        return $stmt->execute([$this->userId, $website, $password]);
    }

    // Retrieve all passwords for the user
    public function getPasswords() {
        $stmt = $this->db->prepare("SELECT website, password, created_at FROM passwords WHERE user_id = ?");
        $stmt->execute([$this->userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Handle form submissions
$db = new Database();
$user = new User($db);
$passwordGenerator = new PasswordGenerator();
$passwordManager = new PasswordManager($db, $_SESSION['user_id'] ?? null);
$registerError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['register'])) {
        $result = $user->register($_POST['username'], $_POST['password']);
        if ($result !== true) {
            $registerError = $result; // Display error message
        }
    } elseif (isset($_POST['login'])) {
        if ($user->login($_POST['username'], $_POST['password'])) {
            header("Location: index.php");
            exit;
        } else {
            $registerError = "Invalid username or password";
        }
    } elseif (isset($_POST['generate'])) {
        $passwordGenerator->setParameters(
            $_POST['length'],
            $_POST['lowercase'],
            $_POST['uppercase'],
            $_POST['numbers'],
            $_POST['special']
        );
        $generatedPassword = $passwordGenerator->generatePassword();
    } elseif (isset($_POST['save'])) {
        $passwordManager->savePassword($_POST['website'], $_POST['password']);
    } elseif (isset($_POST['update_password'])) {
        $user->updatePassword($_SESSION['user_id'], $_POST['new_password']);
    } elseif (isset($_POST['logout'])) {
        // Handle logout: destroy session and redirect
        session_destroy();
        header("Location: index.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Password Manager</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: inline-block; width: 150px; }
        input, button { padding: 5px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .error { color: red; }
    </style>
</head>
<body>
    <?php if (!isset($_SESSION['user_id'])): ?>
        <h2>Register</h2>
        <?php if ($registerError): ?>
            <p class="error"><?php echo htmlspecialchars($registerError); ?></p>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label>Username:</label>
                <input type="text" name="username" required>
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" name="register">Register</button>
        </form>

        <h2>Login</h2>
        <?php if ($registerError && strpos($registerError, "Invalid") !== false): ?>
            <p class="error"><?php echo htmlspecialchars($registerError); ?></p>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label>Username:</label>
                <input type="text" name="username" required>
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" name="login">Login</button>
        </form>
    <?php else: ?>
        <!-- Logout form -->
        <form method="post">
            <button type="submit" name="logout">Logout</button>
        </form>

        <h2>Generate Password</h2>
        <form method="post">
            <div class="form-group">
                <label>Length:</label>
                <input type="number" name="length" value="9" required>
            </div>
            <div class="form-group">
                <label>Lowercase Letters:</label>
                <input type="number" name="lowercase" value="2" required>
            </div>
            <div class="form-group">
                <label>Uppercase Letters:</label>
                <input type="number" name="uppercase" value="3" required>
            </div>
            <div class="form-group">
                <label>Numbers:</label>
                <input type="number" name="numbers" value="2" required>
            </div>
            <div class="form-group">
                <label>Special Characters:</label>
                <input type="number" name="special" value="2" required>
            </div>
            <button type="submit" name="generate">Generate</button>
        </form>

        <?php if (isset($generatedPassword)): ?>
            <p>Generated Password: <?php echo htmlspecialchars($generatedPassword); ?></p>
            <form method="post">
                <div class="form-group">
                    <label>Website:</label>
                    <input type="text" name="website" required>
                </div>
                <div class="form-group">
                    <label>Password:</label>
                    <input type="text" name="password" value="<?php echo htmlspecialchars($generatedPassword); ?>" required>
                </div>
                <button type="submit" name="save">Save Password</button>
            </form>
        <?php endif; ?>

        <h2>Change Password</h2>
        <form method="post">
            <div class="form-group">
                <label>New Password:</label>
                <input type="password" name="new_password" required>
            </div>
            <button type="submit" name="update_password">Update Password</button>
        </form>

        <h2>Saved Passwords</h2>
        <table>
            <tr>
                <th>Website</th>
                <th>Password</th>
                <th>Created At</th>
            </tr>
            <?php foreach ($passwordManager->getPasswords() as $pwd): ?>
                <tr>
                    <td><?php echo htmlspecialchars($pwd['website']); ?></td>
                    <td><?php echo htmlspecialchars($pwd['password']); ?></td>
                    <td><?php echo $pwd['created_at']; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</body>
</html>